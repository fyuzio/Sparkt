$(document).ready(function () {





	$(window).on("load", function () {
		$("a[rel='scrollNav']").mPageScroll2id({
			offset: $("header .navbarWrapp").height(),
			scrollSpeed: 1400,
			autoScrollSpeed: true,
			pageEndSmoothScroll: true,
			targetClass: "activeSection",
			highlightClass: "activeMenu",
			forceSingleHighlight: true,
			//	scrollingEasing: "easeOutQuint",
			scrollEasing: "easeInOutQuint"
		});

	});


	$(".hamburger").on("click", function () {
		$(this).toggleClass("is-active");
		$(".mobileNav").toggleClass("open");
	});

	$(".mobileNav a").on("click", function () {
		$(".hamburger").removeClass("is-active");
		$(".mobileNav").removeClass("open");
	});
	$(".section").on("click", function () {
		$(".hamburger").removeClass("is-active");
		$(".mobileNav").removeClass("open");
	});



	$(".videoPlay").on("click", function () {

		// 	 alert("hi");
		if ($("#HomeVideo").get(0).paused) {
			$("#HomeVideo").get(0).play();
			$(".videoOverlay").fadeOut(400);
			$(".videoPlay").removeClass("paused");

		} else {
			$("#HomeVideo").get(0).pause();
			$(".videoOverlay").fadeIn(400);
			$(".videoPlay").addClass("paused");
		}

	});




	//	 $(".item-video divdivdivdiv.iframeoverlay").on("click", function(){
	//		 
	//		// 	 alert("hi");
	//		// $('.item-video iframe').attr('src', $('iframe').attr('src'));
	//		 $('iframe')[0].contentWindow.postMessage('{"event":"command","func":"' + 'stopVideo' + '","args":""}', '*');
	//		 $(this).fadeOut(600);
	//		  $(this).siblings("iframe")[ 0 ].src += "?autoplay=1&amp;rel=0&amp;showinfo=0&amp;controls=0";
	//		
	//		 
	//	  });




	//youtube pause//     $('iframe').attr('src', $('iframe').attr('src'));
	//youtube pause//  $('iframe')[0].contentWindow.postMessage('{"event":"command","func":"' + 'stopVideo' + '","args":""}', '*');    	




	$(window).on("load", function () {

		$(".scroll-content").mCustomScrollbar({
			//scrollbarPosition: "inside",
			//theme:"rounded",
		});


	});


	$('.keyTakways .owl-carousel').owlCarousel({
		loop: true,
		margin: 0,
		smartSpeed: 1000,
		autoplay: true,
		autoplayTimeout: 5000,
		nav: false,
		dots: true,
		items: 1
	});







	var owlvideo = $('.video-carousel .owl-carousel');
	owlvideo.owlCarousel({
		merge: true,
		loop: true,
		margin: 0,
		nav: true,
		video: true,
		smartSpeed: 700,
		lazyLoad: true,
		center: true,
		//mouseDrag: false,
		videoWidth: false,
		videoHeight: false,
		responsive: {
			// breakpoint from 0 up
			0: {
				items: 1
			},
			// breakpoint from 480 up
			480: {
				items: 1
			},
			// breakpoint from 768 up
			992: {
				items: 3
			},
		},
	});

	//  AFTER SLIDE CHANGE - DO ANIMATION
	owlvideo.on('changed.owl.carousel', function (event) {
		// alert("change");
		$(".item-video .iframeoverlay").fadeIn();
		//$('.item-video iframe').get(0).stopVideo();


	});

	owlvideo.on('translated.owl.carousel', function (event) {


		if ($(".KBYojana").closest(".owl-item").hasClass("center")) {
			$(".KBYojana").addClass("open");
		} else {
			$(".KBYojana").removeClass("open");
		}

		if ($(".nayiSoch").closest(".owl-item").hasClass("center")) {
			$(".nayiSoch").addClass("open");
		} else {
			$(".nayiSoch").removeClass("open");
		}

		if ($(".womensDay").closest(".owl-item").hasClass("center")) {
			$(".womensDay").addClass("open");
		} else {
			$(".womensDay").removeClass("open");
		}

		if ($(".mothersDay").closest(".owl-item").hasClass("center")) {
			$(".mothersDay").addClass("open");
		} else {
			$(".mothersDay").removeClass("open");
		}

		if ($(".pow").closest(".owl-item").hasClass("center")) {
			$(".pow").addClass("open");
		} else {
			$(".pow").removeClass("open");
		}

		if ($(".MMFWebsite").closest(".owl-item").hasClass("center")) {
			$(".MMFWebsite").addClass("open");
		} else {
			$(".MMFWebsite").removeClass("open");
		}

		if ($(".MMFLaunches").closest(".owl-item").hasClass("center")) {
			$(".MMFLaunches").addClass("open");
		} else {
			$(".MMFLaunches").removeClass("open");
		}

		if ($(".Swp").closest(".owl-item").hasClass("center")) {
			$(".Swp").addClass("open");
		} else {
			$(".Swp").removeClass("open");
		}
		if ($(".Bql").closest(".owl-item").hasClass("center")) {
			$(".Bql").addClass("open");
		} else {
			$(".Bql").removeClass("open");
		}

		if ($(".piramlCapital").closest(".owl-item").hasClass("center")) {
			$(".piramlCapital").addClass("open");
		} else {
			$(".piramlCapital").removeClass("open");
		}

		if ($(".Phfl").closest(".owl-item").hasClass("center")) {
			$(".Phfl").addClass("open");
		} else {
			$(".Phfl").removeClass("open");
		}

		if ($(".mGgage").closest(".owl-item").hasClass("center")) {
			$(".mGgage").addClass("open");
		} else {
			$(".mGgage").removeClass("open");
		}

		if ($(".Dhoni").closest(".owl-item").hasClass("center")) {
			$(".Dhoni").addClass("open");
		} else {
			$(".Dhoni").removeClass("open");
		}

		if ($(".JungleBook").closest(".owl-item").hasClass("center")) {
			$(".JungleBook").addClass("open");
		} else {
			$(".JungleBook").removeClass("open");
		}


		if ($(".onePlus").closest(".owl-item").hasClass("center")) {
			$(".onePlus").addClass("open");
		} else {
			$(".onePlus").removeClass("open");
		}



	});




	$(".item-video div.iframeoverlay").click(function (e) {
		e.preventDefault();
		$(this).fadeOut(600);
		//	$(this).siblings("iframe")[ 0 ].src += "?autoplay=1&amp;rel=0&amp;showinfo=0";
		$(this).siblings("iframe")[0].src += "?autoplay=1&amp;rel=0&amp;showinfo=0&amp;controls=0";
	//	alert("Hi");
	});



	$('.tooltip').tooltipster();




	$('.industryCarousel .owl-carousel').owlCarousel({
		loop: true,
		margin: 50,
		nav: false,
		//autoWidth:true,
		autoHeight: true,
		items: 1

	});


	$(".keyTakways").on("mouseenter", function () {
		$(".navigation").removeClass("show");
	});
	
	$(".keyTakways").on("click", function () {
		$(".navigation").removeClass("show");
	});


	$(".keyTakways").on("mouseleave", function () {
		$(".navigation").addClass("show");
	});


	// Chart
	var data = {
		labels: ['2015-16', '2016-17', '2017-18 Q3 Guidance', '2017-18 Q4 Guidance', '2018-19 Projection'],
		series: [
			[0.3, 3.2, 6.5, 7.04, 11],
		]
	};


	var options = {
		seriesBarDistance: 25,
		axisX: {
			// On the x-axis start means top and end means bottom
			position: 'end'
		},
		axisY: {
			// On the y-axis start means left and end means right
			position: 'start',
			onlyInteger: true,
			offset: 80,
			labelInterpolationFnc: function (value) {
				return value + ' CRS'
			},
			scaleMinSpace: 15
		}
	};


	var responsiveOptions = [
		['screen and (min-width: 641px) and (max-width: 1024px)', {
			seriesBarDistance: 10,
			axisX: {
				labelInterpolationFnc: function (value) {
					return value;
				}
			}
		}],

		['screen and (max-width: 640px)', {
			seriesBarDistance: 5,
			axisX: {
				labelInterpolationFnc: function (value) {
					return value;
				}
			}
		}]
	];

	new Chartist.Bar('.ct-chart', data, options, responsiveOptions);

	//Chart


	window.onscroll = function () {
		myFunction()
	};

	function myFunction() {
		if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {

			$(".navigation").addClass("show");

			$("#HomeVideo").get(0).pause();
			$(".videoOverlay").fadeIn(400);
			$(".videoPlay").addClass("paused");

		} else {

			$(".navigation").removeClass("show");



		}
	}
	
	
	
	
	
	
		var $window = $(window); //Window object

	var scrollTime = 1.4; //Scroll time
	var scrollDistance = 250; //Distance. Use smaller value for shorter scroll and greater value for longer scroll

	$window.on("mousewheel DOMMouseScroll", function (event) {

		event.preventDefault();

		var delta = event.originalEvent.wheelDelta / 120 || -event.originalEvent.detail / 3;
		var scrollTop = $window.scrollTop();
		var finalScroll = scrollTop - parseInt(delta * scrollDistance);

		TweenMax.to($window, scrollTime, {
			scrollTo: {
				y: finalScroll,
				autoKill: true
			},
			ease: Power1.easeOut, //For more easing functions see http://api.greensock.com/js/com/greensock/easing/package-detail.html
			autoKill: true,
			overwrite: 5
		});

	});

});
